package ihm;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;

import fr.iut.annotations.Responsable;

public class CofirmationViderPanier extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JScrollPane scrollPane;
	private JTextPane textPane;

	private Panier fenetrePanier;

	/**
	 * Create the dialog.
	 */
	@Responsable("Yao DOSSAVI")
	public CofirmationViderPanier() {
		this.setTitle("Confirmation");
		this.setBounds(100, 100, 350, 150);
		this.getContentPane().setLayout(new BorderLayout());
		this.contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.getContentPane().add(this.contentPanel, BorderLayout.CENTER);
		this.contentPanel.setLayout(new BorderLayout(0, 0));
		this.setLocationRelativeTo(null);
		{
			this.scrollPane = new JScrollPane();
			this.contentPanel.add(this.scrollPane, BorderLayout.CENTER);
		}
		{
			this.textPane = new JTextPane();
			this.textPane.setFont(new Font("Tahoma", Font.PLAIN, 16));
			this.textPane.setEditable(false);
			this.textPane.setText("Voulez-vous vraiment supprimer le panier?");
			this.textPane.setOpaque(false);
			this.scrollPane.setViewportView(this.textPane);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
			this.getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Oui");
				okButton.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						CofirmationViderPanier.this.fenetrePanier.viderPanier();
						CofirmationViderPanier.this.dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				this.getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Non");
				cancelButton.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						CofirmationViderPanier.this.dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

	/**
	 * Faire reference à la fenetre Panier
	 * 
	 * @param fenetrePanier
	 */
	@Responsable("Yao DOSSAVI")
	public void setPanier(Panier fenetrePanier) {
		this.fenetrePanier = fenetrePanier;
	}

}
