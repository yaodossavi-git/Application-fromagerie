package ihm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import fr.iut.annotations.Responsable;
import modele.Article;
import modele.Fromage;
import modele.Fromages;
import modele.OutilsBaseDonneesFromages;

public class Panier extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JLabel labelImagePanier;
	private JTextField textFieldSousTotale;
	private JTextField textFieldTotale;
	private JTextField textFieldExpedition;
	private JComboBox comboBoxTransporteur;

	private List<Fromage> listBaseFromage;
	private Fromages baseFromages;
	private DefaultTableModel modelTable;
	private Double prixSousTotale;
	private Double fraisExpedition;
	private String transporteurSélectionné;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */

	@Responsable("Intisar BINTI")
	public Panier() {
		this.setTitle("L'Artisan du Fromage");
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(900, 600);
		this.setLocationRelativeTo(null);
		this.setMinimumSize(new Dimension(600, 400));

		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setContentPane(this.contentPane);
		this.contentPane.setLayout(new BorderLayout(0, 6));

		// creation list base Fromage
		this.listBaseFromage = this.creationBaseFromage();

		// initialisation des totales
		this.prixSousTotale = 0.0;
		this.fraisExpedition = 0.0;

		// ── NORD : logo | titre | bouton recalculer ──────────────────────────
		JPanel panel = new JPanel();
		this.contentPane.add(panel, BorderLayout.NORTH);
		panel.setLayout(new BorderLayout(5, 0));

		JButton calculerPanier = new JButton("Recalculer Votre Panier");
		this.calculerPrixTotalDuPanier(calculerPanier);
		panel.add(calculerPanier, BorderLayout.EAST);

		JLabel lblNewLabel = new JLabel(" Votre panier");
		lblNewLabel.setForeground(new Color(255, 128, 0));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Rage Italic", Font.PLAIN, 40));
		panel.add(lblNewLabel, BorderLayout.CENTER);

		this.labelImagePanier = new JLabel();
		ImageIcon logoPanierOriginal = new ImageIcon("src/main/resources/images/logo/logo_panier.jpg");
		Image logoPanier40 = logoPanierOriginal.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		ImageIcon logoFromagerie = new ImageIcon(logoPanier40);
		this.labelImagePanier.setIcon(logoFromagerie);
		panel.add(this.labelImagePanier, BorderLayout.WEST);

		// ── CENTRE : table scrollable ─────────────────────────────────────────
		JPanel panel_1 = new JPanel();
		this.contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new BorderLayout(0, 0));
		panel_1.setBorder(new EmptyBorder(10, 10, 10, 10));

		this.table = new JTable();
		this.modelTable = new DefaultTableModel(new Object[][] {},
				new String[] { "Image", "Produit", "Prix", "Quantité", "Total" }) {
			// Changer la class de premier colonne pour ajouter des images
			@Override
			public Class<?> getColumnClass(int columnIndex) {
				if (columnIndex == 0) {
					return ImageIcon.class;
				}
				return super.getColumnClass(columnIndex);
			}
		};
		this.table.setModel(this.modelTable);
		this.table.getColumnModel().getColumn(0).setPreferredWidth(50);
		this.table.getColumnModel().getColumn(0).setMaxWidth(70);
		this.table.setRowHeight(50);
		this.table.setFillsViewportHeight(true);

		JScrollPane scrollPane = new JScrollPane(this.table);
		panel_1.add(scrollPane, BorderLayout.CENTER);

		// ── SUD : transporteur + totaux + boutons ────────────────────────────
		JPanel panel_2 = new JPanel();
		this.contentPane.add(panel_2, BorderLayout.SOUTH);
		panel_2.setLayout(new BorderLayout(0, 4));

		// Transporteur (gauche) + Totaux (droite)
		JPanel panel_4 = new JPanel();
		panel_2.add(panel_4, BorderLayout.CENTER);
		panel_4.setLayout(new BorderLayout(10, 0));

		// Transporteur — gauche
		JPanel panel_3 = new JPanel();
		panel_4.add(panel_3, BorderLayout.CENTER);
		panel_3.setBorder(new TitledBorder(BorderFactory.createEtchedBorder(), "Transporteur"));
		panel_3.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));

		JLabel lblInfoPort = new JLabel("Frais de port offerts à partir de 120€");
		lblInfoPort.setFont(new Font("Tahoma", Font.PLAIN, 13));
		panel_3.add(lblInfoPort);

		this.comboBoxTransporteur = new JComboBox<>(new String[] { "Colissimo", "Chronorelais", "Chronofresh" });
		this.actionPerformedComboBoxTransporteur();
		panel_3.add(this.comboBoxTransporteur);

		// Totaux — droite, empilés avec BoxLayout
		JPanel panel_5 = new JPanel();
		panel_4.add(panel_5, BorderLayout.EAST);
		panel_5.setLayout(new BoxLayout(panel_5, BoxLayout.Y_AXIS));

		JPanel panel_6 = new JPanel();
		panel_5.add(panel_6);
		panel_6.setLayout(new FlowLayout(FlowLayout.RIGHT, 5, 3));

		JLabel textSousTotal = new JLabel("Sous-Total :");
		panel_6.add(textSousTotal);

		this.textFieldSousTotale = new JTextField();
		panel_6.add(this.textFieldSousTotale);
		this.textFieldSousTotale.setColumns(8);
		this.textFieldSousTotale.setEditable(false);

		JPanel panel_7 = new JPanel();
		panel_5.add(panel_7);
		panel_7.setLayout(new FlowLayout(FlowLayout.RIGHT, 5, 3));

		JLabel textExpedition = new JLabel("Expédition :");
		panel_7.add(textExpedition);

		this.textFieldExpedition = new JTextField();
		this.textFieldExpedition.setColumns(8);
		this.textFieldExpedition.setEditable(false);
		panel_7.add(this.textFieldExpedition);

		JPanel panel_8 = new JPanel();
		panel_5.add(panel_8);
		panel_8.setLayout(new FlowLayout(FlowLayout.RIGHT, 5, 3));

		JLabel textTotale = new JLabel("TOTAL :");
		panel_8.add(textTotale);

		this.textFieldTotale = new JTextField();
		this.textFieldTotale.setColumns(8);
		this.textFieldTotale.setEditable(false);
		panel_8.add(this.textFieldTotale);

		// Boutons — bas
		JPanel panel_9 = new JPanel();
		panel_2.add(panel_9, BorderLayout.SOUTH);
		panel_9.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 5));

		JButton btnValiderAchats = new JButton("Valider le panier");
		this.actionPerformedBtnValiderAchats(btnValiderAchats);
		panel_9.add(btnValiderAchats);

		JButton btnViderPanier = new JButton("Vider le panier");
		this.actionPerformedBtnViderPanier(btnViderPanier);
		panel_9.add(btnViderPanier);

		JButton btnContinuerAchats = new JButton("Continuer les achats");
		this.actionPerformedBtnContinuerAchats(btnContinuerAchats);
		panel_9.add(btnContinuerAchats);

	}

	// ====================================================
	// Les méthodes
	// ====================================================

	/***
	 * Creer la list base du fromage
	 * 
	 * @return la liste base de fromages
	 */
	@Responsable("Intisar BINTI")
	public List<Fromage> creationBaseFromage() {
		// recuperation données
		this.baseFromages = OutilsBaseDonneesFromages
				.générationBaseDeFromages(OutilsBaseDonneesFromages.CHEMIN_FICHIER);

		// Convertir les information à une liste
		List<Fromage> listBaseFromage = this.baseFromages.getFromages();
		return listBaseFromage;
	}

	/***
	 * Inserer les infromation du fromage dans le JTable depuis Description
	 * 
	 * @param designationFromage la designation du fromage
	 * @param articleSélectionné l'article du fromage sélectionné
	 * @param quantitéFromage    la quantité du fromage sélectionné
	 * 
	 */
	@Responsable("Intisar BINTI")
	public void setTableauFromage(String designationFromage, Article articleSélectionné, int quantitéFromage) {
		Fromage fromage = Accueil.baseFromages.getFromage(designationFromage);
		String nomProduit = "";
		String nomImage = "";
		double prixUnitaire = 0.0;

		// Construire le nom affiché

		for (Article a : fromage.getArticles()) {
			if (a.equals(articleSélectionné)) {
				nomProduit = fromage.getDésignation() + " - " + a.getClé();
				nomImage = fromage.getNomImage();
				prixUnitaire = a.getPrixTTC();

			}
		}

		// Vérifier si la ligne existe déjà
		for (int i = 0; i < this.modelTable.getRowCount(); i++) {
			String produitExistant = (String) this.modelTable.getValueAt(i, 1);

			if (produitExistant.equals(nomProduit)) {
				// Mettre à jour la quantité et le total
				int ancienneQuantité = (int) this.modelTable.getValueAt(i, 3);
				int nouvelleQuantité = ancienneQuantité + quantitéFromage;
				double nouveauTotal = nouvelleQuantité * prixUnitaire;

				this.modelTable.setValueAt(nouvelleQuantité, i, 3);
				this.modelTable.setValueAt(nouveauTotal, i, 4);
				return; // on arrete ici
			}
		}

		// Sinon, ajouter une nouvelle ligne
		double total = prixUnitaire * quantitéFromage;

		// ajouter l'image du fromage
		ImageIcon icon = new ImageIcon("src/main/resources/images/fromages/hauteur40/" + nomImage + ".jpg");
		this.modelTable.addRow(new Object[] { icon, // Image (colonne 0)
				nomProduit, // Produit (colonne 1)
				String.format("%.2f €", prixUnitaire), // Prix (colonne 2)
				quantitéFromage, // Quantité (colonne 3)
				String.format("%.2f €", total), // Total (colonne 4)
		});
	}

	/***
	 * Set le frais expidition pour le transporteur sélectionné
	 */
	@Responsable("Intisar BINTI")
	public void setFraisExpeditionTransporteur() {

		this.transporteurSélectionné = Panier.this.comboBoxTransporteur.getSelectedItem().toString();
		Double prixST = Panier.this.prixSousTotale;

		if (this.transporteurSélectionné.equals("Colissimo")) {
			this.setFraisExpeditionColissimoEtChronorelais(prixST);

		} else if (this.transporteurSélectionné.equals("Chronorelais")) {
			this.setFraisExpeditionColissimoEtChronorelais(prixST);

		} else if (this.transporteurSélectionné.equals("Chronofresh")) {
			if (prixST < 50.00) {
				Panier.this.fraisExpedition = 23.80;
			} else if (prixST < 80.00) {
				Panier.this.fraisExpedition = 17.80;
			} else if (prixST < 120.00) {
				Panier.this.fraisExpedition = 9.9;
			} else {
				Panier.this.fraisExpedition = 0.0;
			}
		}
	}

	/***
	 * Set le frais expidition pour le transporteur Colissimo et Chronorelais
	 * 
	 * @param prixST prix sous total des produits
	 */
	@Responsable("Intisar BINTI")
	public void setFraisExpeditionColissimoEtChronorelais(Double prixST) {
		if (prixST < 60.00) {
			Panier.this.fraisExpedition = 14.90;
		} else if (prixST < 90.00) {
			Panier.this.fraisExpedition = 9.90;
		} else if (prixST < 120.00) {
			Panier.this.fraisExpedition = 4.90;
		} else {
			Panier.this.fraisExpedition = 0.0;
		}
	}

	/***
	 * Recalculer le sous totale, les frais expedition et le prix total
	 * 
	 * @param calculerPanier JButton
	 */
	@Responsable("Intisar BINTI")
	public void calculerPrixTotalDuPanier(JButton calculerPanier) {
		calculerPanier.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Panier.this.prixSousTotale = 0.0;
				for (int i = 0; i < Panier.this.modelTable.getRowCount(); i++) {
					// convertir le string au Double
					double prixStringToDouble = Double
							.parseDouble(Panier.this.modelTable.getValueAt(i, 4).toString().replace(" €", "") // debut :
																												// 12,45
																												// €
									.replace(",", ".") // fin : 12.45 (permet faire calculation)
					);
					Panier.this.prixSousTotale += prixStringToDouble;
				}
				Panier.this.setFraisExpeditionTransporteur();
				if (Panier.this.prixSousTotale != 0.0) {
					Panier.this.textFieldSousTotale.setText(String.format("%.2f €", Panier.this.prixSousTotale));
					Panier.this.textFieldExpedition.setText(String.format("%.2f €", Panier.this.fraisExpedition));
					Panier.this.textFieldTotale
							.setText(String.format("%.2f €", Panier.this.prixSousTotale + Panier.this.fraisExpedition));
				}

			}
		});
	}

	/***
	 * Vider la panier
	 */
	@Responsable("Intisar BINTI")
	public void viderPanier() {
		// Rendre les quantités à chaque article
		for (int i = 0; i < this.modelTable.getRowCount(); i++) {
			String nomProduitAVider = (String) this.modelTable.getValueAt(i, 1);
			int quantité = (int) this.modelTable.getValueAt(i, 3);

			// Retrouver l'article correspondant et rendre la quantité
			for (Fromage f : this.listBaseFromage) {
				for (Article a : f.getArticles()) {
					String nomProduitArticle = f.getDésignation() + " - " + a.getClé();
					if (nomProduitArticle.equals(nomProduitAVider)) {
						a.rendreQuantité(quantité);
					}
				}
			}
		}

		// Vider le tableau
		this.modelTable.setRowCount(0);

		// Remettre les totaux à zéro
		this.prixSousTotale = 0.0;
		this.textFieldSousTotale.setText("");
		this.textFieldExpedition.setText("");
		this.textFieldTotale.setText("");
	}

	/***
	 * Cacher la fenetre Panier
	 */
	@Responsable("Intisar BINTI")
	public void actionPerformedBtnContinuerAchats(JButton btnContinuerAchats) {
		btnContinuerAchats.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Panier.this.setVisible(false);
			}
		});
	}

	/***
	 * Recalculer le panier et ouvrir la fenetre coordination
	 */
	@Responsable("Yao DOSSAVI")
	public void actionPerformedBtnValiderAchats(JButton btnValiderAchats) {
		btnValiderAchats.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Recalculer avant d'ouvrir la coordination
				Panier.this.prixSousTotale = 0.0;
				for (int i = 0; i < Panier.this.modelTable.getRowCount(); i++) {
					double val = Double.parseDouble(
							Panier.this.modelTable.getValueAt(i, 4).toString().replace(" €", "").replace(",", "."));
					Panier.this.prixSousTotale += val;
				}
				Panier.this.setFraisExpeditionTransporteur();

				Coordination fenCoordination = new Coordination();
				fenCoordination.setPanier(Panier.this);
				fenCoordination.setVisible(true);
			}
		});
	}

	/***
	 * Construire le JDialog pour confirmation vider le panier
	 * 
	 * @param btnVider JButton
	 */
	@Responsable("Intisar BINTI")
	public void actionPerformedBtnViderPanier(JButton btnVider) {
		btnVider.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				CofirmationViderPanier dialogue = new CofirmationViderPanier();
				dialogue.setPanier(Panier.this);
				dialogue.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				dialogue.setVisible(true);
			}
		});
	}

	/***
	 * Set le frais expidition pour le transporteur sélectionné depuis le
	 * comboBoxTransporteur
	 */
	@Responsable("Intisar BINTI")
	public void actionPerformedComboBoxTransporteur() {
		this.comboBoxTransporteur.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Panier.this.setFraisExpeditionTransporteur();
			}
		});
	}

	/**
	 * 
	 * Extraire les données pour l'impresseion de la facture
	 * 
	 * @return
	 */
	@Responsable("Yao DOSSAVI")
	public Object[][] extrairePourFacture() {
		int nbLignes = this.modelTable.getRowCount();
		Object[][] donnees = new Object[nbLignes][4];

		for (int i = 0; i < nbLignes; i++) {
			donnees[i][0] = this.modelTable.getValueAt(i, 1); // Produit
			donnees[i][1] = this.modelTable.getValueAt(i, 2); // Prix unitaire
			donnees[i][2] = this.modelTable.getValueAt(i, 3); // Quantité
			donnees[i][3] = this.modelTable.getValueAt(i, 4); // Total (Prix TTC)
		}
		return donnees;
	}

	/**
	 * 
	 * Retourner la prix total TTC
	 * 
	 * @return la prix total TTC
	 */
	@Responsable("Yao DOSSAVI")
	public double getTotalTTC() {
		return this.prixSousTotale + this.fraisExpedition;
	}

	/**
	 * 
	 * Retourner le transporteur choisi
	 * 
	 * @return nom transporteur
	 */
	@Responsable("Yao DOSSAVI")
	public String getTransporteur() {
		return this.transporteurSélectionné;
	}

	/**
	 * 
	 * Retourner le frais expedition
	 * 
	 * @return le frais expedition
	 */
	@Responsable("Yao DOSSAVI")
	public double getFraisExpedition() {
		return this.fraisExpedition;
	}

	/**
	 * 
	 * Retourner la prix sous totale
	 * 
	 * @return la prix sous totale
	 */
	@Responsable("Yao DOSSAVI")
	public double getPrixSousTotale() {
		return this.prixSousTotale;
	}

}
