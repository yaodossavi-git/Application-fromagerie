package ihm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import fr.iut.annotations.Responsable;
import modele.Fromage;
import modele.Fromages;
import modele.OutilsBaseDonneesFromages;
import modele.TypeLait;

public class Accueil extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JComboBox comboBoxTypeLait;
	private JList<String> JListFromage;
	public static Fromages baseFromages;

	Panier fenetrePanier;

	/**
	 * Launch the application.
	 */
	@Responsable({ "Intisar BINTI", "Yao DOSSAVI", "Maelys PRATI" })
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					Accueil frame = new Accueil();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@Responsable("Intisar BINTI")
	public Accueil() {
		this.setTitle("L'Artisan du Fromage");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(900, 600);
		this.setLocationRelativeTo(null);
		this.setMinimumSize(new Dimension(600, 400));

		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setContentPane(this.contentPane);
		this.contentPane.setLayout(new BorderLayout(0, 0));

		// creation base du fromage
		this.baseFromages = OutilsBaseDonneesFromages
				.générationBaseDeFromages(OutilsBaseDonneesFromages.CHEMIN_FICHIER);

		// instance du panier
		this.fenetrePanier = new Panier(); // 1 seul panier pour toute l'application

		JScrollPane scrollPane = new JScrollPane();
		this.contentPane.add(scrollPane, BorderLayout.CENTER);

		this.JListFromage = new JList(this.construireListeFromageTous(this.baseFromages));
		this.selectionFromageDansJList(); // creation du fenetre description à chaque selection du
											// fromage
		scrollPane.setViewportView(this.JListFromage);

		JPanel panel = new JPanel();
		this.contentPane.add(panel, BorderLayout.NORTH);
		panel.setLayout(new BorderLayout(0, 0));

		JButton boutonPanier = new JButton("Panier");
		this.actionPerformedBoutonPanier(boutonPanier);
		panel.add(boutonPanier, BorderLayout.EAST);

		JLabel lblNewLabel = new JLabel("Nos fromages");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 128, 0));
		lblNewLabel.setFont(new Font("Rage Italic", Font.PLAIN, 50));
		panel.add(lblNewLabel, BorderLayout.CENTER);

		JPanel panel_2 = new JPanel();
		panel_2.setLayout(new BorderLayout(0, 0));
		panel_2.setBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(255, 128, 0)), "Filtre"));
		this.contentPane.add(panel_2, BorderLayout.SOUTH);

		JButton btnQuitter = new JButton("Quitter");
		this.actionPerformedBoutonQuitter(btnQuitter);
		panel_2.add(btnQuitter, BorderLayout.EAST);

		JPanel panel_3 = new JPanel();
		panel_2.add(panel_3, BorderLayout.CENTER);
		panel_3.setLayout(new FlowLayout(FlowLayout.CENTER));

		// ===== LOGO DE FROMAGE =====
		JLabel labelLogoFromagerie = new JLabel("");
		ImageIcon logoFromagerieOriginal = new ImageIcon("src/main/resources/images/logo/logo_image.jpg");
		Image logoFromagerie40 = logoFromagerieOriginal.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		ImageIcon logoFromagerie = new ImageIcon(logoFromagerie40);
		labelLogoFromagerie.setIcon(logoFromagerie);
		panel_3.add(labelLogoFromagerie, BorderLayout.WEST);

		JLabel lblNewLabel_1 = new JLabel("Type au lait");
		panel_3.add(lblNewLabel_1);

		// ===== CREATION LE COMBOBOX TYPE LAIT DU FROMAGE =====
		this.comboBoxTypeLait = new JComboBox();
		this.construireComboBoxTypeLait();
		this.construireListeDeFromage(this.baseFromages);
		panel_3.add(this.comboBoxTypeLait);

	}

	// ====================================================
	// Les méthodes
	// ====================================================

	/***
	 * Construire comboBoxTypeLait
	 */
	@Responsable("Intisar BINTI")
	public void construireComboBoxTypeLait() {
		this.comboBoxTypeLait.addItem("Tous");
		for (TypeLait t : TypeLait.values()) {
			this.comboBoxTypeLait.addItem(t.getTypeDeLait());
		}
	}

	/***
	 * Construire la liste designation tous les fromages depuis la liste base de
	 * fromage
	 * 
	 * @param baseFromages liste base de fromages
	 * @return la liste designation tous les fromages
	 */
	@Responsable("Intisar BINTI")
	public String[] construireListeFromageTous(Fromages baseFromages) {
		// Convertir les information à une liste
		List<Fromage> listBaseFromage = baseFromages.getFromages();

		// Un tableau du designation des fromages
		String[] listeDesignationFromagesTous = new String[listBaseFromage.size()];
		for (int i = 0; i < listBaseFromage.size(); i++) {
			listeDesignationFromagesTous[i] = listBaseFromage.get(i).getDésignation();
		}
		return listeDesignationFromagesTous;
	}

	/***
	 * Construire la liste designation les fromages different type de lait depuis la
	 * liste base de fromage
	 * 
	 * @param baseFromages liste base de fromages
	 * @return la liste designation fromages au lait de
	 */
	@Responsable("Intisar BINTI")
	public void construireListeDeFromage(Fromages baseFromages) {
		this.comboBoxTypeLait.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String selection = Accueil.this.comboBoxTypeLait.getSelectedItem().toString();

				// filtrer liste pour tous les fromages
				if (selection.equals("Tous")) {

					Accueil.this.JListFromage.setListData(Accueil.this.construireListeFromageTous(baseFromages));

				} else if (selection.equals("Vache")) { // filtrer pour les fromage vache
					Accueil.this.construireListeFromageAuLaitDe(baseFromages, selection);

				} else if (selection.equals("Chèvre")) { // filtrer pour les fromage chèvre
					Accueil.this.construireListeFromageAuLaitDe(baseFromages, selection);

				} else if (selection.equals("Brebis")) { // filtrer pour les fromage brebis
					Accueil.this.construireListeFromageAuLaitDe(baseFromages, selection);

				}
			}

		});
	}

	/**
	 * Construire la liste designation les fromages different type de lait depuis la
	 * liste base de fromage
	 * 
	 * @param baseFromages la liste base fromages
	 * @param selection    type de lait sélectionné
	 */
	@Responsable("Intisar BINTI")
	public void construireListeFromageAuLaitDe(Fromages baseFromages, String selection) {
		// Convertir les information à une liste
		List<Fromage> listBaseFromageAuDeLait = baseFromages.fromagesAuLaitDe(TypeLait.getTypeLait(selection));

		// Un tableau du designation des fromages
		String[] listeDesignationFromagesAuDeLait = new String[listBaseFromageAuDeLait.size()];

		for (int i = 0; i < listBaseFromageAuDeLait.size(); i++) {
			listeDesignationFromagesAuDeLait[i] = listBaseFromageAuDeLait.get(i).getDésignation();
		}

		this.JListFromage.setListData(listeDesignationFromagesAuDeLait);
	}

	/***
	 * Ouvrir la fenetre description de fromage quand on clique sur la liste
	 */
	@Responsable("Intisar BINTI")
	public void selectionFromageDansJList() {
		this.JListFromage.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				Description fenetreDescription = new Description();
				String selectionFromage = Accueil.this.JListFromage.getSelectedValue();
				fenetreDescription.setPanier(Accueil.this.fenetrePanier); // passer la référence du Panier existant
				fenetreDescription.setFromage(selectionFromage); // envoie le nom du fromage au fenetre Description
				fenetreDescription.setVisible(true);

			}
		});
	}

	/***
	 * Construire le JDialog pour confirmation quitter l'application
	 * 
	 * @param btnQuitter JButton
	 */
	@Responsable("Intisar BINTI")
	public void actionPerformedBoutonQuitter(JButton btnQuitter) {
		btnQuitter.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ConfirmationFermerAppli dialogue = new ConfirmationFermerAppli();
				dialogue.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				dialogue.setVisible(true);
			}
		});
	}

	/***
	 * Ouvrir la fenetre panier
	 * 
	 * @param btnPanier JButton
	 */
	@Responsable("Intisar BINTI")
	public void actionPerformedBoutonPanier(JButton boutonPanier) {
		boutonPanier.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Accueil.this.fenetrePanier.setVisible(true);
			}
		});
	}

}
