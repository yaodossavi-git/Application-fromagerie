package ihm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import fr.iut.annotations.Responsable;
import modele.Article;
import modele.Fromage;

public class Description extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextArea textDescription;

	private JLabel labelNomFromage;
	private JLabel labelImageFromage;
	private JComboBox comboBoxArticle;
	private JSpinner spinnerQuantitéFromage;

	private String designationFromage;
	private Article articleSélectionné;
	private Panier fenetrePanier;

	/**
	 * 
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	@Responsable("Intisar BINTI")
	public Description() {
		this.setTitle("L'Artisan du Fromage");
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // pour ne pas fermer toute l'application
		this.setSize(800, 400);
		this.setLocationRelativeTo(null);
		this.setMinimumSize(new Dimension(600, 400));

		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setContentPane(this.contentPane);
		this.contentPane.setLayout(new BorderLayout(0, 0));

		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(300, 0));
		this.contentPane.add(panel, BorderLayout.WEST);

		panel.setLayout(new BorderLayout(0, 0));

		this.labelNomFromage = new JLabel("Nom Fromage");
		this.labelNomFromage.setForeground(new Color(255, 128, 0));
		this.labelNomFromage.setFont(new Font("Rage Italic", Font.PLAIN, 40));
		this.labelNomFromage.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(this.labelNomFromage, BorderLayout.NORTH);

		this.labelImageFromage = new JLabel("");
		panel.add(this.labelImageFromage, BorderLayout.CENTER);

		JPanel panel_1 = new JPanel();
		this.contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new BorderLayout(0, 0));
		panel_1.setPreferredSize(new Dimension(225, 0));

		JLabel labelDescription = new JLabel("Description");
		labelDescription.setForeground(new Color(255, 128, 0));
		labelDescription.setFont(new Font("Tahoma", Font.PLAIN, 15));
		panel_1.add(labelDescription, BorderLayout.NORTH);

		this.textDescription = new JTextArea();
		this.textDescription.setEditable(false);
		this.textDescription.setLineWrap(true);
		this.textDescription.setWrapStyleWord(true);
		JScrollPane scrollDescription = new JScrollPane(this.textDescription);
		panel_1.add(scrollDescription, BorderLayout.CENTER);

		JPanel panel_2 = new JPanel();
		this.contentPane.add(panel_2, BorderLayout.SOUTH);
		panel_2.setLayout(new BorderLayout(0, 0));

		JPanel panel_3 = new JPanel();
		panel_2.add(panel_3, BorderLayout.SOUTH);

		JButton btnAjoutPanier = new JButton("Ajouter au panier");
		this.actionPerformedBtnAjoutPanier(btnAjoutPanier);
		panel_3.add(btnAjoutPanier);

		JButton btnAnnuler = new JButton("Annuler");
		this.actionPerformedBtnAnnuler(btnAnnuler);
		panel_3.add(btnAnnuler);

		JPanel panel_4 = new JPanel();
		panel_2.add(panel_4, BorderLayout.NORTH);

		this.comboBoxArticle = new JComboBox();
		this.construireSpinnerQuantitéFromage();
		panel_4.add(this.comboBoxArticle);

		this.spinnerQuantitéFromage = new JSpinner();
		this.spinnerQuantitéFromage.setPreferredSize(new Dimension(50, 22));
		panel_4.add(this.spinnerQuantitéFromage);

	}

	// ====================================================
	// Les méthodes
	// ====================================================

	/**
	 * Faire réference au panier existant
	 * 
	 * @param fenetrePanier
	 */
	@Responsable("Intisar BINTI")
	public void setPanier(Panier fenetrePanier) {
		this.fenetrePanier = fenetrePanier;
	}

	/***
	 * Recevoir les designation fromage qui est cliqué depuis Acceuil
	 * 
	 * @param designationFromage designation fromage
	 */
	@Responsable("Intisar BINTI")
	public void setFromage(String designationFromage) {

		Fromage fromage = Accueil.baseFromages.getFromage(designationFromage);
		// set la designation fromage
		this.designationFromage = fromage.getDésignation();
		this.labelNomFromage.setText(fromage.getDésignation());

		// ajouter l'image du fromage
		ImageIcon icon = new ImageIcon(
				"src/main/resources/images/fromages/hauteur200/" + fromage.getNomImage() + ".jpg");
		this.labelImageFromage.setIcon(icon);

		// ajouter la description du fromage
		this.textDescription.setText(fromage.getDescription());

		// construire ComboBox Articles
		List<Article> listArticles = fromage.getArticles();

		this.comboBoxArticle.removeAllItems();
		for (Article a : listArticles) {
			this.comboBoxArticle.addItem(a);
		}

	}

	/***
	 * Construire le SpinnerQuantitéFromage
	 */
	@Responsable("Intisar BINTI")
	public void construireSpinnerQuantitéFromage() {
		this.comboBoxArticle.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (Description.this.comboBoxArticle.getItemCount() > 0) {
					Description.this.articleSélectionné = (Article) Description.this.comboBoxArticle.getSelectedItem();
					int quantitéEnStock = Description.this.articleSélectionné.getQuantitéEnStock();
					Description.this.spinnerQuantitéFromage.setModel(new SpinnerNumberModel(0, 0, quantitéEnStock, 1));

				}
			}
		});
	}

	/***
	 * Fermer la fenetre description
	 */
	@Responsable("Intisar BINTI")
	public void actionPerformedBtnAnnuler(JButton btnAnnuler) {
		btnAnnuler.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Description.this.dispose();
			}
		});
	}

	/***
	 * Ajouter le fromage selectionné avec son quantité dans le panier
	 */
	@Responsable("Intisar BINTI")
	public void actionPerformedBtnAjoutPanier(JButton btnAjoutPanier) {
		btnAjoutPanier.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String designationFromage = Description.this.designationFromage;
				Description.this.articleSélectionné = (Article) Description.this.comboBoxArticle.getSelectedItem();
				int quantité = (int) Description.this.spinnerQuantitéFromage.getValue();

				if (quantité != 0) {
					// envoie les données à la fenetre Panier
					Description.this.fenetrePanier.setTableauFromage(designationFromage,
							Description.this.articleSélectionné, quantité);

					// mets à jour la quantité du fromage sélectionné
					Description.this.articleSélectionné.préempterQuantité(quantité);
				}
				Description.this.dispose();
			}
		});
	}

}