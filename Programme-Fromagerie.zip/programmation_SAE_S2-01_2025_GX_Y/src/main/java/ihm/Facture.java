package ihm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import fr.iut.annotations.Responsable;

public class Facture extends JFrame {

	private static final long serialVersionUID = 1L;

	private static final Color ORANGE = new Color(211, 134, 76);
	private static final Color GRIS_FOND = new Color(238, 238, 238);

	private static final Font POLICE_TITRE = new Font("Segoe Script", Font.BOLD, 28);
	private static final Font POLICE_ENTETE = new Font("Serif", Font.BOLD, 14);
	private static final Font POLICE_DATE = new Font("Serif", Font.ITALIC, 12);
	private static final Font POLICE_NOM = new Font("Serif", Font.BOLD, 13);
	private static final Font POLICE_NORMALE = new Font("Serif", Font.PLAIN, 13);
	private static final Font POLICE_TOTAL = new Font("Serif", Font.BOLD, 13);
	private static final Font POLICE_MERCI = new Font("Serif", Font.ITALIC, 13);

	private JLabel lblDateHeure = new JLabel();
	private JLabel lblPrenomNom = new JLabel();
	private JLabel lblAdresse = new JLabel();
	private JLabel lblTelephone = new JLabel();
	private JLabel lblMail = new JLabel();
	private JLabel lblTotalTTC = new JLabel("0,00 €");
	private JTextField txtMerci;
	private JTable table;

	private JLabel lblFraisTransport = new JLabel("0,00 €");
	private JLabel lblPrixTotalTTC = new JLabel("0,00 €");

	@Responsable("Yao DOSSAVI")
	// ✅ CORRECTION 1 : fraisTransport et nomTransporteur ajoutés en paramètres
	public Facture(String prenom, String nom, String adresse1, String adresse2, String codePostal, String ville,
			String telephone, String mail, String moyenPaiement, boolean newsletter, Object[][] lignesPanier,
			double totalTTC, double fraisTransport, String nomTransporteur) {

		this.setTitle("L'Artisan du Fromage");
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setMinimumSize(new Dimension(700, 400));
		this.setLocationRelativeTo(null);

		// ✅ CORRECTION 2 : les variables locales inutiles double fraisTransport = 0.0
		// et String nomTransporteur = null sont supprimées,
		// on utilise directement les paramètres reçus
		this.remplirDonnees(prenom, nom, adresse1, adresse2, codePostal, ville, telephone, mail, totalTTC,
				fraisTransport, nomTransporteur, moyenPaiement);

		JPanel contentPane = new JPanel(new BorderLayout(0, 0));
		contentPane.setBackground(Color.WHITE);
		this.setContentPane(contentPane);

		contentPane.add(this.construireNord(), BorderLayout.NORTH);
		contentPane.add(this.construireCentre(lignesPanier), BorderLayout.CENTER);
		contentPane.add(this.construireSud(), BorderLayout.SOUTH);

		this.pack();
	}

	@Responsable("Yao DOSSAVI")
	private void remplirDonnees(String prenom, String nom, String adresse1, String adresse2, String cp, String ville,
			String tel, String mail, double sousTotal, double fraisTransport, String nomTransporteur,
			String moyenPaiement) {

		this.lblPrenomNom.setText(prenom + " " + nom);

		String adresseComplete = adresse1;
		if (adresse2 != null && !adresse2.trim().isEmpty()) {
			adresseComplete += " " + adresse2;
		}
		adresseComplete += " " + cp + " " + ville;
		this.lblAdresse.setText(adresseComplete);
		this.lblTelephone.setText(tel);
		this.lblMail.setText(mail);

		// ✅ CORRECTION 3 : affiche le vrai montant et le transporteur si renseigné
		// (avant : "0,00 € par null")
		this.lblTotalTTC.setText(
				String.format("%.2f €", sousTotal).replace(".", ",")
				+ (nomTransporteur != null ? " par " + nomTransporteur : ""));

		this.lblFraisTransport.setText(String.format("%.2f €", fraisTransport).replace(".", ","));
		this.lblPrixTotalTTC.setText(String.format("%.2f €", sousTotal + fraisTransport).replace(".", ","));

		LocalDateTime maintenant = LocalDateTime.now();
		String jourSemaine = maintenant.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.FRENCH);
		String mois = maintenant.getMonth().getDisplayName(TextStyle.FULL, Locale.FRENCH);
		String dateFormatee = jourSemaine + " " + maintenant.getDayOfMonth() + " " + mois + " " + maintenant.getYear()
				+ ", " + maintenant.format(DateTimeFormatter.ofPattern("HH:mm:ss")) + " heure d'été d'Europe centrale";
		this.lblDateHeure.setText(dateFormatee);
	}

	@Responsable("Yao DOSSAVI")
	private JPanel construireNord() {
		JPanel panel = new JPanel(new BorderLayout(0, 0));
		panel.setBackground(Color.WHITE);
		panel.setBorder(new EmptyBorder(10, 15, 5, 15));

		JLabel lblTitre = new JLabel("Votre facture", SwingConstants.CENTER);
		lblTitre.setFont(POLICE_TITRE);
		lblTitre.setForeground(ORANGE);
		lblTitre.setBorder(new EmptyBorder(10, 0, 12, 0));
		panel.add(lblTitre, BorderLayout.NORTH);

		this.txtMerci = new JTextField("Merci de votre visite !");
		this.txtMerci.setFont(POLICE_MERCI);
		this.txtMerci.setForeground(ORANGE);
		this.txtMerci.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(ORANGE, 1),
				BorderFactory.createEmptyBorder(4, 6, 4, 6)));
		panel.add(this.txtMerci, BorderLayout.CENTER);

		return panel;
	}

	@Responsable("Yao DOSSAVI")
	private JScrollPane construireCentre(Object[][] lignesPanier) {
		JPanel corps = new JPanel();
		corps.setLayout(new BoxLayout(corps, BoxLayout.Y_AXIS));
		corps.setBackground(Color.WHITE);
		corps.setBorder(new EmptyBorder(15, 20, 10, 20));

		corps.add(this.ligneLarge("Fromagerie L'Artisan du Fromage pour vous servir et resservir en fromages",
				POLICE_ENTETE, ORANGE));
		corps.add(Box.createRigidArea(new Dimension(0, 8)));

		JPanel pDate = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
		pDate.setBackground(Color.WHITE);
		pDate.setAlignmentX(Component.LEFT_ALIGNMENT);
		JLabel lblCom = new JLabel("Commande du ");
		lblCom.setFont(POLICE_DATE);
		this.lblDateHeure.setFont(POLICE_DATE);
		pDate.add(lblCom);
		pDate.add(this.lblDateHeure);
		corps.add(pDate);
		corps.add(Box.createRigidArea(new Dimension(0, 15)));

		this.lblPrenomNom.setFont(POLICE_NOM);
		corps.add(this.enveloppeLargeur(this.lblPrenomNom));
		corps.add(this.ligneClient("Adresse : ", this.lblAdresse));
		corps.add(this.ligneClient("Téléphone : ", this.lblTelephone));
		corps.add(this.ligneClient("Mèl : ", this.lblMail));
		corps.add(Box.createRigidArea(new Dimension(0, 20)));

		corps.add(this.construireTableau(lignesPanier));
		corps.add(Box.createRigidArea(new Dimension(0, 12)));

		JPanel pTotal = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
		pTotal.setBackground(Color.WHITE);
		pTotal.setAlignmentX(Component.LEFT_ALIGNMENT);
		pTotal.setMaximumSize(new Dimension(Integer.MAX_VALUE, 25));
		JLabel lblLibTotal = new JLabel("TOTAL TTC COMMANDE : ");
		lblLibTotal.setFont(POLICE_TOTAL);
		this.lblTotalTTC.setFont(POLICE_TOTAL);
		pTotal.add(lblLibTotal);
		pTotal.add(this.lblTotalTTC);
		corps.add(pTotal);

		JPanel pTransport = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
		pTransport.setBackground(Color.WHITE);
		pTransport.setAlignmentX(Component.LEFT_ALIGNMENT);
		pTransport.setMaximumSize(new Dimension(Integer.MAX_VALUE, 25));
		JLabel lblLibTransport = new JLabel("FRAIS DE TRANSPORT : ");
		lblLibTransport.setFont(POLICE_TOTAL);
		this.lblFraisTransport.setFont(POLICE_TOTAL);
		pTransport.add(lblLibTransport);
		pTransport.add(this.lblFraisTransport);
		corps.add(pTransport);

		JPanel pPrixTotal = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
		pPrixTotal.setBackground(Color.WHITE);
		pPrixTotal.setAlignmentX(Component.LEFT_ALIGNMENT);
		pPrixTotal.setMaximumSize(new Dimension(Integer.MAX_VALUE, 25));
		Font policeTotalGras = new Font("Serif", Font.BOLD, 14);
		JLabel lblLibPrixTotal = new JLabel("PRIX TOTAL TTC : ");
		lblLibPrixTotal.setFont(policeTotalGras);
		this.lblPrixTotalTTC.setFont(policeTotalGras);
		pPrixTotal.add(lblLibPrixTotal);
		pPrixTotal.add(this.lblPrixTotalTTC);
		corps.add(pPrixTotal);

		JScrollPane scroll = new JScrollPane(corps);
		scroll.setBorder(null);
		scroll.getVerticalScrollBar().setUnitIncrement(12);
		scroll.setPreferredSize(null);
		return scroll;
	}

	@Responsable("Yao DOSSAVI")
	private JPanel construireTableau(Object[][] lignesPanier) {
		String[] colonnes = { "Produit", "Prix unitaire", "Quantité", "Prix TTC" };

		Object[][] donnees = (lignesPanier != null && lignesPanier.length > 0) ? lignesPanier : new Object[0][4];

		DefaultTableModel modele = new DefaultTableModel(donnees, colonnes) {
			@Override
			public boolean isCellEditable(int r, int c) {
				return false;
			}
		};

		this.table = new JTable(modele);
		this.table.setFont(POLICE_NORMALE);
		this.table.setRowHeight(30);
		this.table.setGridColor(Color.DARK_GRAY);
		this.table.setShowGrid(true);
		this.table.setIntercellSpacing(new Dimension(1, 1));

		JTableHeader entete = this.table.getTableHeader();
		entete.setFont(new Font("Serif", Font.BOLD, 13));
		entete.setBackground(GRIS_FOND);
		entete.setForeground(Color.BLACK);
		((DefaultTableCellRenderer) entete.getDefaultRenderer()).setHorizontalAlignment(SwingConstants.CENTER);

		DefaultTableCellRenderer alDroite = new DefaultTableCellRenderer();
		alDroite.setHorizontalAlignment(SwingConstants.RIGHT);
		DefaultTableCellRenderer alCentre = new DefaultTableCellRenderer();
		alCentre.setHorizontalAlignment(SwingConstants.CENTER);

		this.table.getColumnModel().getColumn(0).setPreferredWidth(200);
		this.table.getColumnModel().getColumn(1).setCellRenderer(alDroite);
		this.table.getColumnModel().getColumn(1).setPreferredWidth(100);
		this.table.getColumnModel().getColumn(2).setCellRenderer(alCentre);
		this.table.getColumnModel().getColumn(2).setPreferredWidth(80);
		this.table.getColumnModel().getColumn(3).setCellRenderer(alDroite);
		this.table.getColumnModel().getColumn(3).setPreferredWidth(100);

		JPanel pTableau = new JPanel(new BorderLayout());
		pTableau.setAlignmentX(Component.LEFT_ALIGNMENT);
				JPanel pTableau1 = new JPanel(new BorderLayout());
		pTableau1.setAlignmentX(Component.LEFT_ALIGNMENT);
		pTableau1.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
		pTableau1.add(entete, BorderLayout.NORTH);
		pTableau1.add(this.table, BorderLayout.CENTER);

		return pTableau1;
	}

	@Responsable("Yao DOSSAVI")
	private JPanel construireSud() {
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		panel.setBackground(Color.WHITE);
		panel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, Color.LIGHT_GRAY));

		JButton btnImprimer = new JButton("Imprimer");
		JButton btnQuitter = new JButton("Quitter");

		this.styleBtn(btnImprimer);
		this.styleBtn(btnQuitter);

		btnImprimer.addActionListener(e -> {
			java.awt.print.PrinterJob job = java.awt.print.PrinterJob.getPrinterJob();
			job.setPrintable((graphics, pageFormat, pageIndex) -> {
				if (pageIndex > 0) return java.awt.print.Printable.NO_SUCH_PAGE;
				this.printAll(graphics);
				return java.awt.print.Printable.PAGE_EXISTS;
			});
			if (job.printDialog()) {
				try {
					job.print();
				} catch (java.awt.print.PrinterException ex) {
					ex.printStackTrace();
				}
			}
		});

		btnQuitter.addActionListener(e -> this.dispose());

		panel.add(btnImprimer);
		panel.add(btnQuitter);
		return panel;
	}

	@Responsable("Yao DOSSAVI")
	private JLabel ligneLarge(String texte, Font police, Color couleur) {
		JLabel lbl = new JLabel(texte);
		lbl.setFont(police);
		lbl.setForeground(couleur);
		lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
		return lbl;
	}

	@Responsable("Yao DOSSAVI")
	private JPanel enveloppeLargeur(JLabel lbl) {
		JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
		p.setBackground(Color.WHITE);
		p.setAlignmentX(Component.LEFT_ALIGNMENT);
		p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 25));
		p.add(lbl);
		return p;
	}

	@Responsable("Yao DOSSAVI")
	private JPanel ligneClient(String libelle, JLabel valeur) {
		JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
		p.setBackground(Color.WHITE);
		p.setAlignmentX(Component.LEFT_ALIGNMENT);
		p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 25));
		JLabel lib = new JLabel(libelle);
		lib.setFont(POLICE_NORMALE);
		valeur.setFont(POLICE_NORMALE);
		p.add(lib);
		p.add(valeur);
		return p;
	}

	@Responsable("Yao DOSSAVI")
	private void styleBtn(JButton btn) {
		btn.setFont(new Font("SansSerif", Font.PLAIN, 12));
		btn.setPreferredSize(new Dimension(100, 30));
	}
}