package ihm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import fr.iut.annotations.Responsable;

public class Coordination extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField fieldNom;
	private JTextField fieldPrenom;
	private JTextField fieldAdresse1;
	private JTextField fieldAdresse2;
	private JTextField fieldCP;
	private JTextField fieldVille;
	private JTextField fieldTel;
	private JTextField fieldMail;

	private JRadioButton rdBtCB;
	private JRadioButton rdbtnPP;
	private JRadioButton rdbtCH;
	private JRadioButton rdbtOUI;
	private JRadioButton rdbtNON;

	private Panier panier;

	@Responsable("Intisar BINTI")
	public Coordination() {
		this.setTitle("L'Artisan du Fromage");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600, 600);
		this.setLocationRelativeTo(null);
		this.setMinimumSize(new Dimension(500, 550));

		// Configuration du contentPane principal
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(15, 20, 15, 20));
		this.setContentPane(this.contentPane);
		this.contentPane.setLayout(new BorderLayout(0, 15));

		// SECTION TITRE
		JLabel lblTitle = new JLabel("Vos coordonnées");
		lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitle.setForeground(new Color(211, 134, 76));
		lblTitle.setFont(new Font("Segoe Script", Font.BOLD, 28));
		this.contentPane.add(lblTitle, BorderLayout.NORTH);

		// PANEL CENTRAL
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
		this.contentPane.add(centerPanel, BorderLayout.CENTER);

		// SECTION FORMULAIRE
		JPanel formPanel = new JPanel();
		formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));

		Dimension labelSize = new Dimension(110, 25);
		Font labelFont = new Font("Tahoma", Font.BOLD, 12);

		// Ligne Nom
		JPanel rowNom = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 3));
		JLabel lblNom = new JLabel("Nom :");
		lblNom.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNom.setPreferredSize(labelSize);
		lblNom.setFont(labelFont);
		this.fieldNom = new JTextField(25);
		rowNom.add(lblNom);
		rowNom.add(this.fieldNom);
		formPanel.add(rowNom);

		// Ligne Prénom
		JPanel rowPrenom = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 3));
		JLabel lblPrenom = new JLabel("Prénom :");
		lblPrenom.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPrenom.setPreferredSize(labelSize);
		lblPrenom.setFont(labelFont);
		this.fieldPrenom = new JTextField(25);
		rowPrenom.add(lblPrenom);
		rowPrenom.add(this.fieldPrenom);
		formPanel.add(rowPrenom);

		// Ligne Adresse 1
		JPanel rowAdresse1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 3));
		JLabel lblAdresse1 = new JLabel("Adresse 1 :", SwingConstants.RIGHT);
		lblAdresse1.setPreferredSize(labelSize);
		lblAdresse1.setFont(labelFont);
		this.fieldAdresse1 = new JTextField(25);
		rowAdresse1.add(lblAdresse1);
		rowAdresse1.add(this.fieldAdresse1);
		formPanel.add(rowAdresse1);

		// Ligne Adresse 2
		JPanel rowAdresse2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 3));
		JLabel lblAdresse2 = new JLabel("Adresse 2 :", SwingConstants.RIGHT);
		lblAdresse2.setPreferredSize(labelSize);
		lblAdresse2.setFont(labelFont);
		this.fieldAdresse2 = new JTextField(25);
		rowAdresse2.add(lblAdresse2);
		rowAdresse2.add(this.fieldAdresse2);
		formPanel.add(rowAdresse2);

		// Ligne Code Postal
		JPanel rowCP = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 3));
		JLabel lblCP = new JLabel("Code postal :", SwingConstants.RIGHT);
		lblCP.setPreferredSize(labelSize);
		lblCP.setFont(labelFont);
		this.fieldCP = new JTextField(25);
		rowCP.add(lblCP);
		rowCP.add(this.fieldCP);
		formPanel.add(rowCP);

		// Ligne Ville
		JPanel rowVille = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 3));
		JLabel lblVille = new JLabel("Ville :", SwingConstants.RIGHT);
		lblVille.setPreferredSize(labelSize);
		lblVille.setFont(labelFont);
		this.fieldVille = new JTextField(25);
		rowVille.add(lblVille);
		rowVille.add(this.fieldVille);
		formPanel.add(rowVille);

		// Ligne Téléphone
		JPanel rowTel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 3));
		JLabel lblTel = new JLabel("Téléphone :", SwingConstants.RIGHT);
		lblTel.setPreferredSize(labelSize);
		lblTel.setFont(labelFont);
		this.fieldTel = new JTextField(25);
		rowTel.add(lblTel);
		rowTel.add(this.fieldTel);
		formPanel.add(rowTel);

		// Ligne Mail
		JPanel rowMail = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 3));
		JLabel lblMail = new JLabel("Mail :", SwingConstants.RIGHT);
		lblMail.setPreferredSize(labelSize);
		lblMail.setFont(labelFont);
		this.fieldMail = new JTextField(25);
		rowMail.add(lblMail);
		rowMail.add(this.fieldMail);
		formPanel.add(rowMail);

		centerPanel.add(formPanel);
		centerPanel.add(javax.swing.Box.createVerticalStrut(15));

		// --- Styles des bordures
		Color orangeBorderColor = new Color(211, 134, 76);
		Font borderFont = new Font("Tahoma", Font.BOLD, 12);

		// SECTION MOYEN DE PAIEMENT
		JPanel pMoyenPaiement = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 8));
		pMoyenPaiement.setMaximumSize(new Dimension(32767, 60)); // Empêche le bloc de trop s'étirer en hauteur
		TitledBorder borderPaiement = new TitledBorder(new LineBorder(orangeBorderColor, 1, true), "Moyen de paiement",
				TitledBorder.LEADING, TitledBorder.TOP, borderFont, orangeBorderColor);
		pMoyenPaiement.setBorder(borderPaiement);

		this.rdBtCB = new JRadioButton("Carte bancaire");
		this.rdbtnPP = new JRadioButton("Paypal");
		this.rdbtCH = new JRadioButton("Chèque");

		ButtonGroup groupPaiement = new ButtonGroup();
		groupPaiement.add(this.rdBtCB);
		groupPaiement.add(this.rdbtnPP);
		groupPaiement.add(this.rdbtCH);

		pMoyenPaiement.add(this.rdBtCB);
		pMoyenPaiement.add(this.rdbtnPP);
		pMoyenPaiement.add(this.rdbtCH);

		centerPanel.add(pMoyenPaiement);
		centerPanel.add(javax.swing.Box.createVerticalStrut(10));

		// SECTION NEWSLETTER
		JPanel pNewsletter = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 8));
		pNewsletter.setMaximumSize(new Dimension(32767, 60));
		TitledBorder borderNewsletter = new TitledBorder(new LineBorder(orangeBorderColor, 1, true),
				"Abonnement à notre Newsletter", TitledBorder.LEADING, TitledBorder.TOP, borderFont, orangeBorderColor);
		pNewsletter.setBorder(borderNewsletter);

		this.rdbtOUI = new JRadioButton("Oui");
		this.rdbtNON = new JRadioButton("Non");

		ButtonGroup groupNewsletter = new ButtonGroup();
		groupNewsletter.add(this.rdbtOUI);
		groupNewsletter.add(this.rdbtNON);

		pNewsletter.add(this.rdbtOUI);
		pNewsletter.add(this.rdbtNON);

		centerPanel.add(pNewsletter);

		// SECTION BOUTONS (Sud)
		JPanel pBoutons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));

		JButton btnOK = new JButton("OK");
		btnOK.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnOK.setPreferredSize(new Dimension(100, 30));

		// AJOUT DE LA CONNEXION
		this.actionPerformedBtnOK(btnOK);

		JButton btnAnnuler = new JButton("Annuler");
		this.actionPerformedBtnAnnuler(btnAnnuler);
		btnAnnuler.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnAnnuler.setPreferredSize(new Dimension(100, 30));

		pBoutons.add(btnOK);
		pBoutons.add(btnAnnuler);

		this.contentPane.add(pBoutons, BorderLayout.SOUTH);
	}

	/**
	 * 
	 * Fermer la fenetre coordination
	 * 
	 * @param btnAnnuler
	 */
	@Responsable("Yao DOSSAVI")
	public void actionPerformedBtnAnnuler(JButton btnAnnuler) {
		btnAnnuler.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Coordination.this.dispose();
			}
		});
	}

	/**
	 * 
	 * Ajouter la connexion avec fenetre facture et envoyer les informations
	 * 
	 * @param btnOK
	 */
	@Responsable("Yao DOSSAVI")
	public void actionPerformedBtnOK(JButton btnOK) {
	    btnOK.addActionListener(new java.awt.event.ActionListener() {
	        @Override
	        public void actionPerformed(java.awt.event.ActionEvent e) {
	            String paiement = "Non renseigné";
	            if (Coordination.this.rdBtCB.isSelected()) {
	                paiement = "Carte bancaire";
	            } else if (Coordination.this.rdbtnPP.isSelected()) {
	                paiement = "Paypal";
	            } else if (Coordination.this.rdbtCH.isSelected()) {
	                paiement = "Chèque";
	            }

	            Object[][] lignes = (Coordination.this.panier != null) ? Coordination.this.panier.extrairePourFacture()
	                    : new Object[0][4];
	            double sousTotal = (Coordination.this.panier != null) ? Coordination.this.panier.getPrixSousTotale()
	                    : 0.0;
	            double fraisPort = (Coordination.this.panier != null) ? Coordination.this.panier.getFraisExpedition()
	                    : 0.0;
	            String transporteur = (Coordination.this.panier != null
	                    && Coordination.this.panier.getTransporteur() != null)
	                            ? Coordination.this.panier.getTransporteur()
	                            : "Non renseigné";

	            // ✅ CORRECTION : fraisPort et transporteur maintenant transmis à Facture
	            Facture fenetreFacture = new Facture(
	                    Coordination.this.fieldPrenom.getText().trim(),
	                    Coordination.this.fieldNom.getText().trim(),
	                    Coordination.this.fieldAdresse1.getText().trim(),
	                    Coordination.this.fieldAdresse2.getText().trim(),
	                    Coordination.this.fieldCP.getText().trim(),
	                    Coordination.this.fieldVille.getText().trim(),
	                    Coordination.this.fieldTel.getText().trim(),
	                    Coordination.this.fieldMail.getText().trim(),
	                    paiement,
	                    Coordination.this.rdbtOUI.isSelected(),
	                    lignes,
	                    sousTotal,
	                    fraisPort,      // ← ajouté
	                    transporteur    // ← ajouté
	            );

	            fenetreFacture.setVisible(true);
	        }
	    });
	}

	/**
	 * 
	 * Faire reference avec la panier existant
	 * 
	 * @param panier
	 */
	@Responsable("Yao DOSSAVI")
	public void setPanier(Panier panier) {
		this.panier = panier;
	}
}
